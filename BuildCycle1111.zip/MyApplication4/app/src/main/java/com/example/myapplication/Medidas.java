package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Medidas extends AppCompatActivity {
    EditText esterno;
    EditText cavalo;
    EditText braco;
    double quadroMTB;
    double quadroSpeed;
    double selim;
    double topMesa;
    double e = 0;
    double b = 0;
    double c = 0;
    static String terreno;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medidas);
        getSupportActionBar().hide();
        esterno = findViewById(R.id.esterno1);
        cavalo = findViewById(R.id.cavalo1);
        braco = findViewById(R.id.braco1);
    }


    public void CalculoMTB() {
        e = Double.parseDouble(esterno.getText().toString());
        c = Double.parseDouble(cavalo.getText().toString());
        b = Double.parseDouble(braco.getText().toString());

        if (terreno == "estrada de chão" || terreno == "misto") {
            quadroMTB = Math.round(((c * 0.67 - 10) * 0.393700787)*100.0)/100.0;
        } else {
            quadroSpeed = Math.round((c * 0.67)*100.0)/100.0;
        }
    }

    public void selim() {
       //selim = c * 0.883;
        selim = Math.round((c * 0.883)*100.0)/100.0;
    }

    public void topMesa() {
        //topMesa = ((e - c + b) / 2) + 4;
        topMesa = Math.round((((e - c + b) / 2) + 4)*100.0)/100.0;
    }

    public void telaRelatorio(View view){
        Intent i = new Intent(Medidas.this, Relatorio.class);
        startActivity(i);

        CalculoMTB();
        selim();
        topMesa();

        Componentes.quadroMTB = quadroMTB;
        Relatorio.tamanhoMTB = quadroMTB;
        Componentes.quadroSpeed = quadroSpeed;
        Relatorio.tamanhoSpeed = quadroSpeed;
        Componentes.selim = selim;
        Relatorio.alturaSelim= selim;
        Componentes.topMesa = topMesa;
        Relatorio.tamanhoTop = topMesa;
    }
}


