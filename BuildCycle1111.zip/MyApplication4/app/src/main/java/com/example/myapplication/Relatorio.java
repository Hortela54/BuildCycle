package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Relatorio extends AppCompatActivity {
    static double tamanhoMTB;
    static double tamanhoSpeed;
    static double alturaSelim;
    static double tamanhoTop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorio);
        getSupportActionBar().hide();

        System.out.println(tamanhoTop);

        TextView tamanhoQuadro = (TextView)findViewById(R.id.quadro);
        if(tamanhoMTB == 0){
            tamanhoQuadro.setText(tamanhoSpeed+"");
            Toast.makeText(Relatorio.this, tamanhoSpeed+"", Toast.LENGTH_LONG).show();
        }else{
            tamanhoQuadro.setText(tamanhoMTB+"");
        }

        TextView selim = (TextView)findViewById(R.id.selim);
        selim.setText(alturaSelim+"");

        TextView mesa = (TextView)findViewById(R.id.mesa);
        mesa.setText(tamanhoTop+"");
    }

}