package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Modalidade extends AppCompatActivity {
    String objetivo = "";
    String terreno = "";
    String distancia = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modalidade);
        getSupportActionBar().hide();
    }

    public void Radioobjetivo() {
        RadioButton locomocao, esporte, treino;
        locomocao = findViewById(R.id.locomocao);
        esporte = findViewById(R.id.esporte);
        treino = findViewById(R.id.treino);
        if(locomocao.isChecked()){
            objetivo = "locomoção";
        }
        else if(esporte.isChecked()){
            objetivo = "esporte";
        }
        else if(treino.isChecked()){
            objetivo = "treino";
        }
        else{
            Toast.makeText(Modalidade.this, "Selecione o objetivo.", Toast.LENGTH_LONG).show();

        }
    }
    public void Radiodistancia (){
        RadioButton leve, medio, alto;
        leve = findViewById(R.id.leve);
        medio = findViewById(R.id.medio);
        alto = findViewById(R.id.alto);
        if(leve.isChecked()){
            distancia = "leve";
        }
        else if(medio.isChecked()){
            distancia = "médio";
        }
        else if(alto.isChecked()){
            distancia = "alto";
        }
        else{
            Toast.makeText(Modalidade.this, "Selecione a distância.", Toast.LENGTH_LONG).show();
        }
        Toast.makeText(Modalidade.this, distancia, Toast.LENGTH_LONG).show();
    }

    public void Radioterreno (){
        RadioButton asfalto, estrada, misto;
        asfalto = findViewById(R.id.asfalto);
        estrada = findViewById(R.id.estrada);
        misto = findViewById(R.id.misto);
        if(asfalto.isChecked()){
            terreno = "asfalto";
        }
        else if(estrada.isChecked()){
            terreno = "estrada de chão";
        }
        else if(misto.isChecked()){
            terreno = "misto";
        }
        else{
            Toast.makeText(Modalidade.this, "Selecione o terreno.", Toast.LENGTH_LONG).show();
        }
    }

    public String getTerreno(){
        return terreno;
    }

    public void TelaMedida (View view){
        Intent i = new Intent(Modalidade.this, Medidas.class);
        startActivity(i);

        Toast.makeText(Modalidade.this, objetivo, Toast.LENGTH_LONG).show();

        Radiodistancia();
        Radioobjetivo();
        Radioterreno();

        Componentes.distancia = distancia;
        Medidas.terreno = terreno;
        Componentes.terreno = terreno;
        Componentes.objetivo = objetivo;

    }
}
