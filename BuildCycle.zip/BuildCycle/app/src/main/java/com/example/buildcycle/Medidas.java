package com.example.buildcycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Medidas extends AppCompatActivity {
    EditText altura;
    EditText cavalo;
    EditText braco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medidas);
        getSupportActionBar().hide();
        altura = findViewById(R.id.altura1);
        cavalo = findViewById(R.id.cavalo1);
        braco = findViewById(R.id.braco1);
    }

    public void medidasPessoa(View view){
        int a = Integer.parseInt(altura.getText().toString());
        int b = Integer.parseInt(braco.getText().toString());
        int c = Integer.parseInt(cavalo.getText().toString());
    }

}