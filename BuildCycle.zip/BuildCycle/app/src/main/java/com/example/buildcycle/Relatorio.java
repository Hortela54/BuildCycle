package com.example.buildcycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Relatorio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorio);
    }
}