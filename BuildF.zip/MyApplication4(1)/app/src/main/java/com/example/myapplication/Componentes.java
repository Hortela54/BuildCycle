package com.example.myapplication;

public class Componentes {
    //objetivo
    static String terreno;
    static String distancia;
    static String objetivo;
    //Medidas
    static double topMesa;
    static double quadroSpeed;
    static double quadroMTB;
    static double selim;
    //componentes
    static String marchas;
    static String grupo;
    static String freio;
    static String garfo;
    static String modalidade;

    public static String[] Calculo() {
        String [] componentes = new String[5];
        if (terreno == "estrada de chão" || terreno == "misto") {
            if (distancia == "leve" && objetivo == "locomoção") {
                marchas = "21 ou 24 velocidades";
                grupo = "Grupos Shimano Tourney ou X-Time";
                freio = "Freio a disco mecânico";
                garfo = "Suspensão a mola simples";
                modalidade = "MTB";

            } else if ((distancia == "leve" && objetivo == "esporte") || (distancia == "medio" && objetivo == "locomoção")) {
                marchas = "21 ou 24 velocidades";
                grupo = "Grupos Shimano Tourney";
                freio = "Freio a disco hidráulico";
                garfo = "Suspensão a mola com trava";
                modalidade = "MTB";

            } else if ((distancia == "medio" && objetivo == "esporte")|| (distancia == "leve" && objetivo == "treino")) {
                marchas = "18, 27 ou 12 velocidades";
                grupo = "Grupos Shimano Acera, Shimano Alivio ou Sram SX";
                freio = "Freio hidráulico";
                garfo = "Suspensão a mola com trava";
                modalidade = "MTB";

            } else if (distancia == "medio" && objetivo == "treino") {
                marchas = "11 ou 12 velocidades";
                grupo = "Grupos Shimano Deore, Shimano SLX, Sram NX ou Sram GX";
                freio = "Freio Hidráulico";
                garfo = "Suspensão hidráulica";
                modalidade = "MTB";

            } else if (distancia == "alto" && objetivo == "locomoção") {
                marchas =  "18, 27 ou 12 velocidades";
                grupo = "Grupos Shimano Acera, Shimano Alivio ou Sram SX";
                freio = "Freio hidráulico";
                garfo = "Suspensão a mola com trava";
                modalidade = "MTB";

            } else if (distancia == "alto" && objetivo == "esporte") {
                marchas = "11 ou 12 velocidades";
                grupo = "Grupos Shimano Deore, Shimano SLX, Sram NX ou Sram GX";
                freio = "Freio Hidráulico";
                garfo = "Suspensão hidráulica";
                modalidade = "MTB";

            } else if (distancia == "alto" && objetivo == "treino") {
                marchas = "11 ou 12 velocidades";
                grupo = "Shimano XT, Shimano XTR, Sram XG1 ou Sram XX1";
                freio = "Freio hidráulico";
                garfo = "Suspensão hidráulica";
                modalidade = "MTB";

            }
        } else {
            if (distancia == "leve" && objetivo == "locomoção") {
                marchas = "14, 21 velocidades";
                grupo = "Shimano Tourney";
                freio = "Freio a disco mecânico ou ferradura";
                garfo = "Garfo rígido alumínio";
                modalidade = "Speed";

            } else if ((distancia == "leve" && objetivo == "esporte") || (distancia == "medio" && objetivo == "locomoção")) {
                marchas = "16 velocidades";
                grupo = "Shimano Claris";
                freio = "Freio a disco mecânico ou ferradura";
                garfo = "Garfo rígido de alumínio";
                modalidade = "Speed";

            } else if ((distancia == "medio" && objetivo == "esporte")|| (distancia == "leve" && objetivo == "treino")) {
                marchas = "18, 11 velocidades";
                grupo = "Shimano Sora ou Sram Apex";
                freio = "Freio ferradura ou a disco hidráulico";
                garfo = "Garfo rígido de alumínio";
                modalidade = "Speed";

            } else if (distancia == "medio" && objetivo == "treino") {
                marchas = "10, 20 velocidades";
                grupo = "Shimano Tiagra ou Sram Apex";
                freio = "Freio a disco hidráulico";
                garfo = "Garfo rígido de carbono";
                modalidade = "Speed";

            } else if (distancia == "alto" && objetivo == "locomoção") {
                marchas = "18, 11 velocidades";
                grupo = "Shimano Sora ou Sram Apex";
                freio = "Freio ferradura ou a disco hidráulico";
                garfo = "Garfo rígido de alumínio";
                modalidade = "Speed";

            } else if (distancia == "alto" && objetivo == "esporte") {
                marchas = "10, 20 velocidades";
                grupo = "Shimano Tiagra ou Sram Apex";
                freio = "Freio ferradura a disco hidráulico";
                garfo = "Garfo rígido de carbono";
                modalidade = "Speed";

            } else if (distancia == "alto" && objetivo == "treino") {
                marchas = "11,12, 22 velocidades";
                grupo = "Shimano Ultegra, Shimano Dura-Ace, Sram Force e Sram Red";
                freio = "Freio ferradura a disco hidráulico";
                garfo = "Garfo rígido de carbono";
                modalidade = "Speed";
            }
        }
        componentes[0] = marchas;
        componentes[1] = grupo;
        componentes[3] = garfo;
        componentes[2] = freio;
        componentes[4] = modalidade;
        return componentes;
    }
}

