package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Modalidade extends AppCompatActivity {
    String objetivo = "";
    String terreno = "";
    String distancia = "";
    AlertDialog.Builder jorge;
    int verifica1 = 0;
    int verifica2 = 0;
    int verifica3 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modalidade);
        getSupportActionBar().hide();
        jorge = new AlertDialog.Builder(this);
    }

    public void Radioobjetivo() {
        RadioButton locomocao, esporte, treino;
        locomocao = findViewById(R.id.locomocao);
        esporte = findViewById(R.id.esporte);
        treino = findViewById(R.id.treino);
        if(locomocao.isChecked()){
            objetivo = "locomoção";
            verifica1 = 1;
        }
        else if(esporte.isChecked()){
            objetivo = "esporte";
            verifica1 = 1;
        }
        else if(treino.isChecked()){
            objetivo = "treino";
            verifica1 = 1;
        }
        else{
           // Toast.makeText(Modalidade.this, "Selecione o objetivo.", Toast.LENGTH_LONG).show();
            jorge.setTitle("Selecione o objetivo.");
            jorge.setMessage("Você precisa selecionar um objetivo");
            jorge.show();

        }
    }
    public void Radiodistancia (){
        RadioButton leve, medio, alto;
        leve = findViewById(R.id.leve);
        medio = findViewById(R.id.medio);
        alto = findViewById(R.id.alto);
        if(leve.isChecked()){
            distancia = "leve";
            verifica2 = 1;
        }
        else if(medio.isChecked()){
            distancia = "medio";
            verifica2 = 1;
        }
        else if(alto.isChecked()){
            distancia = "alto";
            verifica2 = 1;
        }
        else{
            //Toast.makeText(Modalidade.this, "Selecione a distância.", Toast.LENGTH_LONG).show();
            jorge.setTitle("Selecione a distância.");
            jorge.setMessage("Você precisa selecionar uma distância");
            jorge.show();
        }
    }

    public void Radioterreno (){
        RadioButton asfalto, estrada, misto;
        asfalto = findViewById(R.id.asfalto);
        estrada = findViewById(R.id.estrada);
        misto = findViewById(R.id.misto);
        if(asfalto.isChecked()){
            terreno = "asfalto";
            verifica3 = 1;
        }
        else if(estrada.isChecked()){
            terreno = "estrada de chão";
            verifica3 = 1;
        }
        else if(misto.isChecked()){
            terreno = "misto";
            verifica3 = 1;
        }
        else{
           // Toast.makeText(Modalidade.this, "Selecione o terreno.", Toast.LENGTH_LONG).show();
            jorge.setTitle("Selecione o terreno.");
            jorge.setMessage("Você precisa selecionar um terreno");
            jorge.show();
        }
    }

    public String getTerreno(){
        return terreno;
    }

    public void TelaMedida (View view){
        Radiodistancia();
        Radioobjetivo();
        Radioterreno();

        Componentes.distancia = distancia;
        Medidas.terreno = terreno;
        Componentes.terreno = terreno;
        Componentes.objetivo = objetivo;

        if(verifica()){
            Intent i = new Intent(Modalidade.this, Medidas.class);
            startActivity(i);
        }
    }
    public boolean verifica(){
        if(verifica1 == 1 && verifica2 == 1 && verifica3 == 1){
            return true;
        }
        return false;
    }
}
